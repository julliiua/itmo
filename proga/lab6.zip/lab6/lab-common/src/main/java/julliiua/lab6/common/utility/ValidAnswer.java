package julliiua.lab6.common.utility;

public interface ValidAnswer<T> {
    T getAnswer();
}